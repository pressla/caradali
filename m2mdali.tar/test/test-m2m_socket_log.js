
var socketlog=require('../m2m_socket_log.js');

//socketlog.options.mac 			= '00:00:00:00:00:00';
socketlog.options.firmversion 	= 'v0815';
socketlog.options.configversion = 'vConfig007';
socketlog.options.config 		= 'confi config';

socketlog.push();

